<!-- Web Company Profile "General Solutions"
**********************************************
* Developer    : Indra Styawantoro
* Company      : Indra Studio
* Release Date : 1 Januari 2017
* Website      : www.indrasatya.com
* E-mail       : indra.setyawantoro@gmail.com
* Phone        : +62-856-6991-9769
-->

<?php
session_start();
// hapus session
session_destroy();

// alihkan ke halaman login (index.php) dan berikan alert = 2
header('Location: index.php?alert=2');
?>